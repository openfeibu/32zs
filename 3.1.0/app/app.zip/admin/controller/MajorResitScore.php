<?php
/**
 * Created by PhpStorm.
 * User: FHYI
 * Date: 2019/10/31
 * Time: 16:12
 */

namespace app\admin\controller;
use app\admin\model\School as SchoolModel;
use app\admin\model\Major as MajorModel;
use app\admin\model\RecruitMajor as RecruitMajorModel;
use app\admin\model\MajorResitScore as MajorResitScoreModel;
use app\admin\model\Score as ScoreModel;
use app\admin\model\Subject as SubjectModel;
use app\admin\model\Export as ExportModel;
use app\admin\controller\Auth;
use think\Db;
use think\Cache;
use think\Loader;
use think\Session;
//recruit_major_score
class MajorResitScore extends Base
{
    public function __construct()
    {
        parent::__construct();
        $this->schoolModel = new SchoolModel();
        $this->scoreModel = new ScoreModel();
        $this->MajorResitScoreModel = new MajorResitScoreModel();
        $this->exprot_model = new ExportModel();
        $Auth = new Auth();
        $admin_auth = Session('admin_auth');
        $admin_group = $Auth->getGroups($admin_auth['aid']);
        $this->assign('admin_group',$admin_group[0]);
        Session::set('admin_group',$admin_group[0]);
    }

   //2019.11.1
    public function fail_score_list()
    {
        $search_key = trim(input('search_key', ''));

        $school_list = $this->schoolModel->get_school_list_rmi($this->admin['recruit_major_id']);

        $school_id = input('school_id', $school_list[0]['school_id']);
        //2019.11.7
        // $school_now_id = input('school_id');
        // if($school_now_id)
        //     $school_id = $school_now_id;
        // else
        //     $school_id = $school_list[0]['school_id'];

        // dump($school_now_id);

        $major_list = MajorModel::get_major_list($school_id,$this->admin['recruit_major_id']);

        $major_id = input('major_id', $major_list['0']['major_id']);

        $major = MajorModel::get_major_detail($major_id, $school_id);


        $major_score_status = input('major_score_status', '');
        // if ($major_score_status == 1) {
        //     $map['ms.major_score_status'] = $major_score_status;
        // } else if ($major_score_status == '') {

        // } else {
        //     $where .= '( ms.major_score_status IS NULL or ms.major_score_status <= 0)';
        // }
        
        
        // dump($major['subjects']);
        $all_subject_list = [];

        $all_subject_list = $major['subjects'];

        $fail_member_list_ids = [];

        //所有专业 all_subject_list
        // dump($all_subject_list);
        foreach ($all_subject_list as $key => $subject)
        {
            $subject_id = $subject['subject_id'];
            $pass_score = $subject['max_score'] * 0.6;

            $where = "ms.major_score_status = 1 AND ms.major_score != '' AND ms.major_score < ".$pass_score ." AND ms.subject_id =".$subject_id;
            //人数查出
            $member_list_ids = Db::name('major_score')->alias("ms")
                ->join(config('database.prefix').'member_list m','m.member_list_id = ms.member_list_id')
                ->join(config('database.prefix').'major mj','mj.major_id = m.major_id')
                ->where($where)
                ->column('ms.member_list_id');

            // dump($member_list_ids);
            $fail_member_list_ids = array_merge($fail_member_list_ids,$member_list_ids);
            //写入补考表
            if($member_list_ids){
                foreach ($member_list_ids as $list_key => $list_value) {
                    $check_fail = Db::name('recruit_major_score')->where('member_list_id',$list_value)->where('subject_id',$subject_id)->find();
                    if(!$check_fail){
                        $recruit_major_score_data['member_list_id'] =  $list_value;
                        $recruit_major_score_data['subject_id'] =  $subject_id;
                        $res = Db::name('recruit_major_score')->insert($recruit_major_score_data);
                    }
                }

            }
        }

        //人数查出
        // halt($fail_member_list_ids);
        
        // $all_subject_list = [[
        //     "subject_id" => 73,
        //     "school_id" => 8,
        //     "major_id" => 14,
        //     "enrollment_id" => 261,
        //     "subject_name" => "市场营销",
        //     "year" => "2018",
        //     "max_score" => 100
        //   ]];
        //   dump($all_subject_list);
        $all_subject_list = [];
        $subject_ids =  input('subject_id');
        if($subject_ids){
            foreach ($major['subjects'] as $key => $value) {
                if($value['subject_id'] == $subject_ids){
                    $all_subject_list[] = $value;
                }
            }
        }else{
            $all_subject_list = $major['subjects'];
        }

        // $where="";
        // if ($major_score_status == 1) {
        //     $map['ms.recruit_major_score_status'] = $major_score_status;
        // }else if ($major_score_status == '') {

        // }else {
        //     $where = 'ms.recruit_major_score_status IS NULL or ms.recruit_major_score_status <= 0';
        // }

        $major_subject_name_arr = array_column($all_subject_list, 'subject_name');
        $major_subject_id_arr = array_column($all_subject_list, 'subject_id');

        $this->assign('major_subject_name_arr', $major_subject_name_arr);

        $fail_member_list_id_where = implode(',',$fail_member_list_ids);
        // echo $fail_member_list_id_where;
        if(!$fail_member_list_id_where)
        {
            $score_list = [];
            $page = [];
        }else{
            $where = "ms.member_list_id in (".$fail_member_list_id_where.") ";
            // $where .= "AND ms.recruit_major_score_status = ".$major_score_status;
            // $major_score_status = (int)$major_score_status;
            // echo intval($major_score_status);
            //查询成绩  补考的
            $data = $this->MajorResitScoreModel->getFailMajorScoreList($where, $search_key, $all_subject_list,$major_score_status);
            // dump($data);
            $score_list = $data['score_list'];

            //查询科目
            $major = MajorModel::get_major_detail($major_id, $school_id);
             
            $status = config("status");

            //整理数据
            $score_list = $this->MajorResitScoreModel->handleMajorScoreList($score_list, $major_subject_name_arr, $status);
            // dump($score_list);
            // halt($score_list);

            $page = $data['page'];
        }

        $this->assign('major_id', $major_id);
        $this->assign('school_id',$school_id);
        $this->assign('school_list',$school_list);
        $this->assign('major_list', $major_list);
        // dump($major_list);
        $this->assign('data', $score_list);
        $this->assign('page', $page);
        $this->assign('search_key', $search_key);
        $this->assign('major_subject_id_arr', $major_subject_id_arr);
        $this->assign('all_subject_list', $major['subjects']);
        $this->assign('subject_id', $subject_ids);

        $this->assign('major_score_status', $major_score_status);

        $major_score_status_list = ['','0','1'];
        $this->assign('major_score_status_list', $major_score_status_list);

        if (request()->isAjax()) {
            return $this->fetch('major_resit_score/ajax_fail_score_list');
        } else {
            return $this->fetch('major_resit_score/fail_score_list');
        }
    }

    //修改数据
    public function fail_score_runadd()
    {
        $member_list_id = $_POST['member_list_id'];
        $subject_id = $_POST['subject_id'];
        if(!$member_list_id || !$subject_id){
            $this->error('参数错误！');
        }
        $major_score = $_POST['score'];
        if(is_array($major_score))
        {
            $major_score = array_filter($major_score);
            foreach ($major_score as $key => $val)
            {
                $data = $this->MajorResitScoreModel->majorrecruitScoreAdd($member_list_id,$subject_id[$key],$val);
            }
        }else{
            $data = $this->MajorResitScoreModel->majorrecruitScoreAdd($member_list_id,$subject_id,$major_score);
        }

        if($data['error']){
            $this->error($data['content']);
        }else{
            $this->success($data['content'],url('admin/Score/score_list'));
        }
    }
    //审核
    public function score_active()
    {
        $p = input('p');
        $ids = input('n_id/a');
        if(empty($ids)){
            $this -> error("请选择列表",url('admin/MajorResitScore/fail_score_list',array('page' => $p)));
        }
        if(is_array($ids)){
            $where = 'member_list_id in('.implode(',',$ids).')';
        }else{
            $where = 'member_list_id ='.$ids;
        }

        $rst=Db::name('recruit_major_score')->where($where)->where('recruit_major_score','<>','')->setField('recruit_major_score_status',1);
        if($rst!==false){
            $this->success("操作成功",url('admin/MajorResitScore/fail_score_list',array('page' => $p)));
        }else{
            $this -> error("操作失败！",url('admin/MajorResitScore/fail_score_list',array('page' => $p)));
        }
    }


    //导出
    public function check_score_list_export()
    {
        $major_id = input('major_id','');
        $school_id = input('school_id', '');
        //$subject_ids = input('subject_id/a');
        $subject_id = input('subject_id');
        $unauditing_count = Db::name('member_list')->alias('m')
            ->join(config('database.prefix').'recruit_major_score ms','m.member_list_id = ms.member_list_id','left')
            ->join(config('database.prefix').'subject s','s.subject_id = ms.subject_id');
        if($subject_id)
        {
            $unauditing_count = $unauditing_count->where('s.subject_id','=',$subject_id);
        }
        $unauditing_count = $unauditing_count->where('ms.recruit_major_score_status IS NUll or ms.recruit_major_score_status <= 0')
            ->where(['m.major_id' => $major_id,'m.school_id' => $school_id])
            ->where(get_year_where('m'))->group('m.member_list_id')
            ->count();
        if($unauditing_count>0)
        {
            $this->error("该专业存在未审核成绩，无法导出。");
        }
        $this->success('导出');
    }
    public function score_list_export()
    {
        $major_id = input('major_id','');

        $school_id = input('school_id', '');

        $map['m.major_id'] = $major_id;

        $map['m.school_id'] = $school_id;

        $map['ms.recruit_major_score_status'] = 1;

        $subject_id = input('subject_id');
        //$subject_ids = input('subject_id/a') ? implode(',', input('subject_id/a')) : '';
        $subject_ids = $subject_id;

        $subject_list = SubjectModel::get_subject_list($major_id, $school_id, '', $subject_ids);

        // $data = $this->scoreModel->getMajorScoreList($map,'','',$subject_list,0);
        $data = $this->MajorResitScoreModel->getMajorScoreList($map,'','',$subject_list);

        // halt($subject_ids);

        $major = MajorModel::get_major_detail($major_id,$school_id);

        $school = Db::name('school')->where(['school_id' =>$school_id ])->find();

        if($subject_id)
        {
            $file_name = '过程考核成绩单';
        }else{
            $file_name = '转段考核总成绩单';
        }
        $title = '对口  '.$school['school_name'].'  '.get_grade().$major['major_name'].'  '.$file_name;

        $major_subject_name_arr = array_column($subject_list, 'subject_name');

        //$major_subject_name_arr = $major['major_subject_name_arr'];

        $data = $this->scoreModel->handleMajorScoreList($data['score_list'],$major_subject_name_arr,config("status_title"));

        $field_titles = ['序号','姓名','中职考生号','身份证号'];
        $i = 4;
        foreach ($major_subject_name_arr as $k => $mv) {
            $field_titles[$i] = $mv;
            $i++;
        }
        if($subject_id)
        {
            $field_titles[$i] = '审核状态';
        }else{
            $field_titles[$i] = '转段考核总成绩';
            $field_titles[$i+1] = '审核状态';
        }
        $fields = ['no','member_list_nickname','ZexamineeNumber','member_list_username','major_name'];
        $i = 4; $j = 0;
        foreach ($major_subject_name_arr as $k => $mv) {
            $fields[$i] = 'major_'.$j;
            $i++;
            $j++;
        }
        if($subject_id)
        {
            $fields[$i] = 'status_desc';
        }else{
            $fields[$i] = 'major_score_total';
            $fields[$i + 1] = 'status_desc';
        }
        $table = $school['school_name'].get_grade().$major['major_name'].$file_name.date('Ymd');
        $this->exprot_model->header_name = sprintf(config('pdf_common.header_name'),'   '.$this->recruit_major_name.'   ');
        $this->exprot_model->university_score_list_export_pdf($field_titles,$fields,$data,$table,$title);
        return false;

    }
}